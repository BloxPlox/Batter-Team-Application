/*
Batter Application Final Project
Author: Nathan Minnick
Date: 5/2/2020
File: BatterTextFile.java
*/

package murach.db;

import java.io.*;
import java.nio.file.*;
import java.util.*;

import murach.business.Batter;

//creates BatterTextFile for storing values
public final class BatterTextFile implements DAO<Batter> {
    private List<Batter> batters = null;
    private Path battersPath = null;
    private File battersFile = null;
    private final String FIELD_SEP = "\t";

    public BatterTextFile() {
        //gets the file path
        battersPath = Paths.get("batters.txt");
        try {
            //if the file path does not exist, it will tell the user that it is creating the path
            if (Files.notExists(battersPath)) {
                System.out.println("********************");
                System.out.println("Data file not found.");
                System.out.println("********************");
                System.out.println("Creating file: " + battersPath.toAbsolutePath() + "\n");
                Files.createFile(battersPath);
            }
        } 
        catch(IOException e) {
            System.out.println(e);
        }
        battersFile = battersPath.toFile();
        batters = this.getAll();
    }

    @Override
    public List<Batter> getAll() {
        //lists the batters
        if (batters != null) {
            return batters;
        }

        //if there is batters saved, it will list them
        batters = new ArrayList<>();
        if (Files.exists(battersPath)) {
            try (BufferedReader in = new BufferedReader(new FileReader(battersFile))) 
            {
                String line = in.readLine();
                while (line != null) {
                    String[] fields = line.split(FIELD_SEP);
                    int batID = Integer.valueOf(fields[0]);
                    String batName = fields[1];
                    int batAvg = Integer.valueOf(fields[2]);
                    int totalBases = Integer.valueOf(fields[3]);
                    double slugPer = Double.valueOf(fields[4]);
                    double basePer = Double.valueOf(fields[5]);
                    
                    Batter b = new Batter(batID, batName, batAvg, totalBases, slugPer, basePer);
                    batters.add(b);
                }
            } catch (IOException e) {
                System.out.println(e);
                return null;
            }
        } else {
            System.out.println(
                    battersPath.toAbsolutePath() + " doesn't exist.");
            return null;            
        }
        return batters;
    }

    @Override
    public Batter get(int batID) {
        //gets all batters
        for (Batter b : batters) {
            if (b.getBatID() == batID) {
                return b;
            }
        }
        return null;
    }

    //saves all batter info to the batter file
    private boolean saveAll() {
        try (PrintWriter out = new PrintWriter(
                               new BufferedWriter(
                               new FileWriter(battersFile))))  
        {
            for (Batter b : batters) {
                out.print(b.getBatID() + FIELD_SEP);
                out.print(b.getBatName() + FIELD_SEP);
                out.print(b.getBatAvg() + FIELD_SEP);
                out.print(b.getTotalBases() + FIELD_SEP);
                out.print(b.getSlugPer() + FIELD_SEP);
                out.print(b.getBasePer());
            }
            return true;
        } catch (IOException e) {
            System.out.println(e);
            return false;
        }
    }
    
    @Override
    public boolean add(Batter b) {
        batters.add(b);
        return this.saveAll();
    }

    @Override
    public boolean delete(Batter b) {
        batters.remove(b);
        return this.saveAll();
    }

    @Override
    public boolean update(Batter newBatter) {
        Batter oldBatter = this.get(newBatter.getBatID());
        int i = batters.indexOf(oldBatter);
        batters.remove(i);

        batters.add(i, newBatter);

        return this.saveAll();
    }
}