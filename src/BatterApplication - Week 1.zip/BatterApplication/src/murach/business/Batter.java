/*
Batter Application Final Project
Author: Nathan Minnick
Date: 4/25/2020
File: Batter.java
*/

package murach.business;

import java.text.NumberFormat;

public class Batter {
    
    //initializing variables
    private int batID;
    private String batName;
    private int batAvg;
    private int totalBases;
    private double slugPer;
    private double basePer;

    //initializes Batter class
    public Batter() {
        this(0, "", 0, 0, 0.0, 0.0);
    }

    //adds values to be saved from the Batter class
    public Batter(int batID, String batName, int batAvg, int totalBases, double slugPer, double basePer) {
        this.batID = batID;
        this.batName = batName;
        this.batAvg = batAvg;
        this.totalBases = totalBases;
        this.slugPer = slugPer;
        this.basePer = basePer;
    }

    //sets batter id
    public void setBatID(int batID) {
        this.batID = batID;
    }
    
    //gets batter id
    public int getBatID() {
        return batID;
    }
    
    //sets batter name
    public void setBatName(String batName) {
        this.batName = batName;
    }

    //gets batter name
    public String getBatName() {
        return batName;
    }
    
    //sets batter average
    public void setBatAvg(int batAvg) {
        this.batAvg = batAvg;
    }

    //gets batter average
    public int getBatAvg() {
        return batAvg;
    }

    //sets total bases
    public void setTotalBases(int totalBases) {
        this.totalBases = totalBases;
    }

    //gets total bases
    public int getTotalBases() {
        return totalBases;
    }
    
    //sets slug percentage
    public void setSlugPer(double slugPer) {
        this.slugPer = slugPer;
    }

    //ges slug percentage
    public double getSlugPer() {
        return slugPer;
    }
    
    //sets base percentage
    public void setBasePer(double basePer) {
        this.basePer = basePer;
    }
    
    //gets base percentage
    public double getBasePer() {
        return basePer;
    }
    
    //sets the slug percentage to be formatted as a percent
    public String getSlugPerFormatted() {
        NumberFormat percent = NumberFormat.getPercentInstance();
        return percent.format(slugPer);
    }
    
    //sets the base percentage to be formatted as a percent
    public String getBasePerFormatted() {
        NumberFormat percent = NumberFormat.getPercentInstance();
        return percent.format(basePer);
    }
}