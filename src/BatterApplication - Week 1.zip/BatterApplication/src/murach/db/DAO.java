/*
Batter Application Final Project
Author: Nathan Minnick
Date: 4/25/2020
File: DAO.java
*/

package murach.db;

import java.util.List;

//creates the DAO interface
public interface DAO<T> {
    T get(int batID);
    List<T> getAll();
    boolean add(T t);
    boolean update(T t);
    boolean delete(T t);
}