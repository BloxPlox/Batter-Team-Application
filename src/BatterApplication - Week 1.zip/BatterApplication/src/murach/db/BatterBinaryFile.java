/*
Batter Application Final Project
Author: Nathan Minnick
Date: 4/25/2020
File: BatterBinaryFile.java
*/

package murach.db;

import java.io.*;
import java.nio.file.*;
import java.util.*;

import murach.business.Batter;

//creates BatterBinaryFile for storing values
public final class BatterBinaryFile implements DAO<Batter> {
    private List<Batter> batters = null;
    private Path battersPath = null;
    private File battersFile = null;
    private final String FIELD_SEP = "\t";

    public BatterBinaryFile() {
        //gets the file path
        battersPath = Paths.get("batters.bin");
        try {
            //if the file path does not exist, it will tell the user that it is creating the path
            if (Files.notExists(battersPath)) {
                System.out.println("********************");
                System.out.println("Data file not found.");
                System.out.println("********************");
                System.out.println("Creating file: " + battersPath.toAbsolutePath() + "\n");
                Files.createFile(battersPath);
            }
        } 
        catch(IOException e) {
            System.out.println(e);
        }
        battersFile = battersPath.toFile();
        batters = this.getAll();
    }

    @Override
    public List<Batter> getAll() {
        //lists the batters
        if (batters != null) {
            return batters;
        }

        //if there is batters saved, it will list them
        batters = new ArrayList<>();
        if (Files.exists(battersPath)) {
            try (DataInputStream in = 
                    new DataInputStream(
                            new BufferedInputStream(
                                    new FileInputStream(battersFile)))
                ) {

                while (in.available() > 0) {
                    int batID = in.readInt();
                    String batName = in.readUTF();
                    int batAvg = in.readInt();
                    int totalBases = in.readInt();
                    double slugPer = in.readDouble();
                    double basePer = in.readDouble();

                    Batter b = new Batter(batID, batName, batAvg, totalBases, slugPer, basePer);
                    batters.add(b);
                }
            } catch (IOException e) {
                System.out.println(e);
                return null;
            }
        } else {
            System.out.println(
                    battersPath.toAbsolutePath() + " doesn't exist.");
            return null;            
        }
        return batters;
    }

    @Override
    public Batter get(int batID) {
        //gets all batters
        for (Batter b : batters) {
            if (b.getBatID() == batID) {
                return b;
            }
        }
        return null;
    }

    //saves all batter info to the batter file
    private boolean saveAll() {
        try (DataOutputStream out = 
                    new DataOutputStream(
                            new BufferedOutputStream(
                                    new FileOutputStream(battersFile)))
            )  {

            for (Batter b : batters) {
                out.write(b.getBatID());
                out.writeUTF(FIELD_SEP);
                out.writeUTF(b.getBatName());
                out.writeUTF(FIELD_SEP);
                out.write(b.getBatAvg());
                out.writeUTF(FIELD_SEP);
                out.write(b.getTotalBases());
                out.writeUTF(FIELD_SEP);
                out.writeDouble(b.getSlugPer());
                out.writeUTF(FIELD_SEP);
                out.writeDouble(b.getBasePer());
            }
            return true;
        } catch (IOException e) {
            System.out.println(e);
            return false;
        }
    }
    
    @Override
    public boolean add(Batter b) {
        batters.add(b);
        return this.saveAll();
    }

    @Override
    public boolean delete(Batter b) {
        batters.remove(b);
        return this.saveAll();
    }

    @Override
    public boolean update(Batter newBatter) {
        Batter oldBatter = this.get(newBatter.getBatID());
        int i = batters.indexOf(oldBatter);
        batters.remove(i);

        batters.add(i, newBatter);

        return this.saveAll();
    }
}